## Objetivos
Can you find the robots? `https://jupiter.challenges.picoctf.org/problem/36474/` ([link](https://jupiter.challenges.picoctf.org/problem/36474/)) or http://jupiter.challenges.picoctf.org:36474
## Solucion
picoCTF{ca1cu1at1ng_Mach1n3s_477ce}
Inspecionar codigo de la pagina del navegador
usando robot.txt al final del url


## Referencias
[Robot.txt](https://es.wikipedia.org/wiki/Est%C3%A1ndar_de_exclusi%C3%B3n_de_robots)
