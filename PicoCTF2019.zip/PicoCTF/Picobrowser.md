This website can be rendered only by **picobrowser**, go and catch the flag! `https://jupiter.challenges.picoctf.org/problem/26704/` ([link](https://jupiter.challenges.picoctf.org/problem/26704/)) or http://jupiter.challenges.picoctf.org:26704

picoCTF{p1c0_s3cr3t_ag3nt_e9b160d0}
![[Pasted image 20230309090930.png]]