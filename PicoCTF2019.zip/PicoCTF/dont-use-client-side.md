## Objetivos
Can you break into this super secure portal? `https://jupiter.challenges.picoctf.org/problem/37821/` ([link](https://jupiter.challenges.picoctf.org/problem/37821/)) or http://jupiter.challenges.picoctf.org:37821
## Solucion
picoCTF{no_clients_plz_1a3c89}
ver el codigo de fuente y despues en la parte de abajo buscar pico y seguir el orden 
de menor a mayor pico 1 hasta pico n

## Referencias
