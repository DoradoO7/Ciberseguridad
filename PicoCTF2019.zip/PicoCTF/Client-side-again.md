## Objetivos
Can you break into this super secure portal? `https://jupiter.challenges.picoctf.org/problem/37821/` ([link](https://jupiter.challenges.picoctf.org/problem/37821/)) or http://jupiter.challenges.picoctf.org:37821
## Solucion
ordenar un poco con logi el jsnice
picoCTF{not_this_again_337115}

## Referencias
Ligas: - javascript obfuscation - [https://jscrambler.com/products/code-...](https://www.youtube.com/redirect?event=video_description&redir_token=QUFFLUhqbWx6SGRYN1BRVncxXzF3SVhkc21RT0ZHT3gtd3xBQ3Jtc0trZ3BlS0htbFZ4RlZMTEFMZElfVE1fc2FHcmJEVkFFTHdjZ0JxU1ltd3h5WmF5a3VuSkd4ZzExT1lnTkxZWTItVWhTMWplYk1NeHY0d0E3dG5Yek9CaWJnc2REWlNoRFFZNmhzQkJKa2Rfd2ZFRDFxbw&q=https%3A%2F%2Fjscrambler.com%2Fproducts%2Fcode-integrity%2Fjavascript-obfuscation&v=rsPT722MkzQ) - javascript deobfuscation: - [http://jsnice.org/](https://www.youtube.com/redirect?event=video_description&redir_token=QUFFLUhqbU9kLUFWZTBNMXRWWVRQd3Q4cXJCNXVIck9wQXxBQ3Jtc0trQVNDYXctSC1fQnNUNWtCOThrN0J0d1pfci13Tm1aZkZjY01lZmk0RTk0RXRGemRuVWgxWkpVSnJfbS12blVDSW5fdHI3MklQejlocFRTZm9QY1RJUEpVTU5RZkpTMWlxQ0ZPeFJIV3cyb2xtdjF2MA&q=http%3A%2F%2Fjsnice.org%2F&v=rsPT722MkzQ), [https://beautifier.io/](https://www.youtube.com/redirect?event=video_description&redir_token=QUFFLUhqa3ZCQ1VySS1ZdmFXU1JYQk9VXzI3RktwUjdWUXxBQ3Jtc0tsZ3UtTTZaRHBKbWtvUWFBSjdPTlkwNGJqdGJmQWF0eTZ4ZUJrQ1BvbDZUM2VvS18wN3NuSTRwYTREd1M0MUszeVhiNVljbFYyemc3c2EyYVJSVW5RcUtIdUZMbkZYd2tZZS01ZzhrdGtTSWt5dkFVSQ&q=https%3A%2F%2Fbeautifier.io%2F&v=rsPT722MkzQ)

http://jsnice.org/