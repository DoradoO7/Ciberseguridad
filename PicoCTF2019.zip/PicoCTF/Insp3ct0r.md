## Objetivos
Kishor Balan tipped us off that the following code may need inspection: `https://jupiter.challenges.picoctf.org/problem/41511/` ([link](https://jupiter.challenges.picoctf.org/problem/41511/)) or http://jupiter.challenges.picoctf.org:41511
## datos de acceso

## Solucion

picoCTF{tru3_d3_t3ct1ve_0r_ju5t_lucky?832b0699}
Inspecionar codigo de la pagina del navegador

## Referencias

